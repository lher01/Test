const forms = document.querySelectorAll('form');

forms.forEach((form) => {
  const output = form.querySelector('output, pre');

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const formData = new FormData(form);
    const entries = [...formData.entries()]
      .filter(([key, value]) => value !== '' && value !== undefined && value !== null);

    const summary = entries.length
      ? entries.map(([name, value]) => `${name}=${value}`).join('\n')
      : 'Keine benannten Felder vorhanden.';

    if (output) {
      output.textContent = 'Lokal geprüft – keine Daten versendet.\n' + summary;
      output.hidden = false;
    }
  });

  const callbackCheckbox = document.getElementById('rueckruf');
  const telefonField = document.getElementById('telefon');

  if (callbackCheckbox && telefonField) {
    const toggleTelefon = () => {
      telefonField.required = callbackCheckbox.checked;
      telefonField.disabled = !callbackCheckbox.checked;
      telefonField.setAttribute(
        'aria-required', callbackCheckbox.checked ? 'true' : 'false'
      );
    };

    callbackCheckbox.addEventListener('change', toggleTelefon);
    toggleTelefon();
  }
});
